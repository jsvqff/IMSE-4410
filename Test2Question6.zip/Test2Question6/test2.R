library('caret')

#import data
data <- read.csv(file.choose())
summary(data)

#Convert factors and numeric based on the data type
colnames <- c('Sex','Cholesterol','Drug','BP')
data[,colnames] <- lapply(data[,colnames] , factor)
summary(data)

# filling missing values for `Age` with median or mode:
hist(data$Age) 
data$Age = replace(data$Age , is.na(data$Age), median(data$Age, na.rm = TRUE)) #replaces missing values with median

data$BP = replace(data$BP , is.na(data$BP), "0") #replaces missing values in fbs with mode
summary(data)

#split data into training and testing
set.seed(15)
data_splitting <- createDataPartition(data$Drug, p=0.8, list=FALSE)
training_data <- data[data_splitting,]
testing_data <- data[-data_splitting,]

summary(training_data)

#train RF and Neural Network models
RF_fit <- train(Drug ~., data=training_data, method='rf', ntree=10)
ANN_fit <- train(Drug ~., data=training_data, method='nnet', trace=F)

summary(ANN_fit)

#variable importance of RF and Neural Network models
varImp(RF_fit)
plot(varImp(RF_fit))

#Predict on the testing Dataset
RF_predict = predict(RF_fit,newdata=testing_data)

#performance measures for the predicted output
confusionMatrix(testing_data$Drug, RF_predict, mode = "everything")

