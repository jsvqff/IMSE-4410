install.packages('caret')
library('caret')

#import data
data <- read.csv(file.choose())
summary(data)

#Remove unnecessary columns and columns with high missing values
cleandata <- subset(data, select = -c(id,ca)) #ca has many missing values; 
summary(cleandata)

#Convert factors and numeric based on the data type
colnames <- c('sex','cp','fbs','restecg','exang','slope','thal','HeartDisease')
cleandata[,colnames] <- lapply(cleandata[,colnames] , factor)
summary(cleandata)

#there are 2 blank cells in "restecg". We will first make them NAs and then replace it with the most common category in that column
cleandata$restecg[cleandata$restecg == ""] <- NA

cleandata <- subset(cleandata, select = -c(slope,thal)) #slope and thal have many blank values. So they must be removed as well

#Deal with any incorrect values
cleandata$oldpeak[cleandata$oldpeak < 0] <- NA #Negative oldpeak is not feasible. 
cleandata$chol[cleandata$chol == 0] <- NA #0 cholesterol is not possible. So we remove it from the data
cleandata$trestbps[cleandata$trestbps == 0] <- NA # 0 value for trestbps is not possible. So we remove it from the data

# Handling missing values: to fill missing values for `chol` with mean,median or mode:
hist(cleandata$chol) #appears to be normal so we can use mean imputation
cleandata$chol = replace(cleandata$chol , is.na(cleandata$chol), mean(cleandata$chol, na.rm = TRUE)) #replaces missing values in chol column with mean of that column. Mean is calculated by ignoring missing values

hist(cleandata$trestbps) #appears to be somewhat symmeterical => will use mean imputation
cleandata$trestbps = replace(cleandata$trestbps , is.na(cleandata$trestbps), mean(cleandata$trestbps, na.rm = TRUE)) #replaces missing values in trestbps column with mean of that column. Mean is calculated by ignoring missing values

cleandata$fbs = replace(cleandata$fbs , is.na(cleandata$fbs), "FALSE") #replaces missing values in fbs with mode (in this case it is false since it is the most commonly occuring category)

cleandata$restecg = replace(cleandata$restecg , is.na(cleandata$restecg), "normal") #replaces missing values in restecg with mode 
cleandata$exang = replace(cleandata$exang , is.na(cleandata$exang), "FALSE") #replaces missing values in exang with mode 


hist(cleandata$thalch) #appears to be somewhat skewed => will use median imputation
cleandata$thalch = replace(cleandata$thalch , is.na(cleandata$thalch), median(cleandata$thalch, na.rm = TRUE)) #replaces missing values in thalch with median 

hist(cleandata$oldpeak) #appears to be somewhat skewed => will use median imputation
cleandata$oldpeak = replace(cleandata$oldpeak , is.na(cleandata$oldpeak), median(cleandata$oldpeak, na.rm = TRUE)) #replaces missing values in oldpeak with median



summary(cleandata)

#split data into training and testing
set.seed(15)
data_splitting <- createDataPartition(cleandata$HeartDisease, p=0.8, list=FALSE)
training_data <- cleandata[data_splitting,]
testing_data <- cleandata[-data_splitting,]

summary(training_data)

#train RF and Neural Network models
RF_fit <- train(HeartDisease ~., data=training_data, method='rf', ntree=100)
ANN_fit <- train(HeartDisease ~., data=training_data, method='nnet', trace=F)

summary(ANN_fit)

#Plot the variable importance of RF and Neural Network models
varImp(RF_fit)
plot(varImp(RF_fit))

varImp(ANN_fit)
# As plot(varImp(ANN_fit)) will throw an error, so it needs to be plotted through ggplot

vi <- varImp(ANN_fit) #The result is stored in the variable vi
overall_importance <- vi$importance[, "Overall", drop = FALSE] #extracts the "Overall" column from the matrix of variable importances that is contained within vi$importance
print(overall_importance) #prints the overall_importance matrix to the console

overall_importance <- data.frame(Feature = rownames(vi$importance), Importance = vi$importance[, "Overall"]) # creates a data frame from the variable importances, with two columns: one for the feature names (row names from vi$importance) and one for the corresponding overall importance scores.

# Using ggplot to create a chart to display the variable importance of ANN_fit
ggplot(overall_importance, aes(x = 0, xend = Importance, y = reorder(Feature, Importance), yend = reorder(Feature, Importance))) +
  geom_segment(size = 0.5, color = "black") +  # Drawing a black line segment
  geom_point(aes(x = Importance, y = reorder(Feature, Importance)), size = 1, color = "blue") +  #Adding a blue point
  labs(x = "Importance", y = "", title = "Variable Importance of ANN Model") +
  theme_minimal()  # A minimal theme for aesthetics


#Predict on the testing Dataset
RF_predict = predict(RF_fit,newdata=testing_data)
ANN_predict = predict(ANN_fit,newdata=testing_data)


#Compute the performance measures for the predicted output
confusionMatrix(testing_data$HeartDisease, RF_predict, mode = "everything")
confusionMatrix(testing_data$HeartDisease, ANN_predict, mode = "everything")
