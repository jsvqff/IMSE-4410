install.packages("caret") #Classification and Regression Training
library(caret) #load the caret package for use

#d/e
#Step 1: Read/Load the data
raw_data <- read.csv(file.choose(), header=T)

raw_data$Salary <- as.factor(raw_data$Salary)
raw_data$US_Native <- as.factor(raw_data$US_Native)
raw_data$Gender <- as.factor(raw_data$Gender)
raw_data$Race <- as.factor(raw_data$Race)
raw_data$Relationship <- as.factor(raw_data$Relationship)
raw_data$Marital.Status <- as.factor(raw_data$Marital.Status)
raw_data$Education <- as.factor(raw_data$Education)
raw_data$Workclass <- as.factor(raw_data$Workclass)

summary(raw_data) #provides descriptive statistics of all columns in the data 

CleanData <- raw_data[complete.cases(raw_data),]
summary(CleanData)

column <- "Age"
histogram <- hist(CleanData[[column]], main = paste("Histogram of", column), xlab = column)

variable_name <- "Marital.Status" 
variable_counts <- table(CleanData[[variable_name]])
pie(variable_counts, labels = paste(names(variable_counts), ": ", variable_counts), main = paste("Pie Chart of", variable_name))



#f
set.seed(15)
DataSplitting <- createDataPartition(CleanData$Salary, p = 0.75, list = F)
trainingData <- CleanData[DataSplitting,]
testingData <- CleanData[-DataSplitting,]

lr_fit <- train(Salary ~., data = trainingData, method = 'glm')
summary(lr_fit)

lr_predict <- predict(lr_fit, newdata = testingData)
confusionMatrix(testingData$Salary, lr_predict)



#f
set.seed(15)
# Split the data into training (75%) and testing (25%) sets
split_index <- createDataPartition(CleanData$Salary, p = 0.75, list = FALSE)
train_data <- CleanData[split_index, ]
test_data <- CleanData[-split_index, ]

# Train a logistic regression model
logistic_model <- glm(Salary ~ ., data = CleanData, family = binomial)

# Extract variable significance
variable_significance <- summary(logistic_model)$coefficients
significant_variables <- variable_significance[variable_significance[, "Pr(>|z|)"] < 0.05, ]
cat("Significant Variables:\n")
print(significant_variables)

# Create the confusion matrix
predictions <- predict(logistic_model, newdata = test_data, type = "response")
threshold <- 0.5
predicted_class <- ifelse(predictions > threshold, 1, 0)
confusion_matrix <- table(Actual = test_data$Salary, Predicted = predicted_class)
cat("\nConfusion Matrix:\n")
print(confusion_matrix)

# iii. Calculate accuracy, sensitivity, specificity, and F1 score
TP <- confusion_matrix[2, 2]
TN <- confusion_matrix[1, 1]
FP <- confusion_matrix[1, 2]
FN <- confusion_matrix[2, 1]

accuracy <- (TP + TN) / sum(confusion_matrix)
sensitivity <- TP / (TP + FN)
specificity <- TN / (TN + FP)
f1_score <- 2 * (sensitivity * specificity) / (sensitivity + specificity)

cat("\nAccuracy: ", accuracy, "\n")
cat("Sensitivity (True Positive Rate): ", sensitivity, "\n")
cat("Specificity (True Negative Rate): ", specificity, "\n")
cat("F1 Score: ", f1_score, "\n")

# iv. Determine and interpret odds ratios
odds_ratio_female <- exp(coef(logistic_model)["GenderFemale"])
odds_ratio_us_native <- exp(coef(logistic_model)["USNative"])
cat("\nOdds Ratio for Females over Males: ", odds_ratio_female, "\n")
cat("Odds Ratio for US Natives over Non-US Individuals: ", odds_ratio_us_native, "\n")



#g
colname <- c('Age', 'Workclass', 'Education', 'Marital.Status', 'Relationship', 'Race', 'Gender', 'Working.Hours.per.week', 'US_Native', 'Salary')
CleanData[,colname] <- lapply(CleanData[,colname], factor)

summary(CleanData)

DataSplitting <- createDataPartition(CleanData$Salary, p = 0.75, list = F)
train_data <- CleanData[DataSplitting, ]
test_data <- CleanData[-DataSplitting, ]

RF_fit <- train(Salary ~., data = train_data, method = "rf", ntree = 50)

varImp(RF_fit)
plot(varImp(RF_fit))

RF_predict <- predict(RF_fit, newdata = test_data)
confusionMatrix(test_data$Salary, RF_predict)


